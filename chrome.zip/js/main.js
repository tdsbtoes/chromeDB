//**** main loading logic

$(document).ready(function(){
	
	var _DB = {},
		$BOX = $('body'),
		$login = $BOX.find('#login').show(),
		$errMsg = $login.find('#login_err')
		;
	
	
	$BOX.find('#loader').hide();
	$BOX.find('#submit').click(userLogin);
	$login.find('#site, #user, #pw').change(clearErrorMsg);
	
	
	//@@@@ functions @@@@//
	
	function userLogin() {
		var $u = $BOX.find('#user'),
			$p = $BOX.find('#pw'),
			$s = $BOX.find('#site'),
			err = '';
		
		//**** error checking
		if (!$s.val()) {
			err = ['Please choose your Site', $s];
		}
		else if (!$u.val()) {
			err = ['Please type in your username', $u];
		}
		else if (!$p.val()) {
			err = ['Please type in your password', $p];
		}
		
		
		if (err) {
			$errMsg.html(err[0]);
			err[1].focus();
			return false;
		}
		else {
			//**** encrypt info and check local/server -- return userid
			
			//**** if okay, prep & load UI
			$login.hide();
			$( "#db_choices_radio" ).buttonset();
			
			//**** 
			$BOX.find('#db').show();
		}
		
	} // end userLogin
	
	
	function clearErrorMsg() {
		
		if (this.value != '') $errMsg.html('');
		
	} // end clearErrorMsg
	
	
	//@@@@ end functions @@@@//
	
}); //END ready
